from __future__ import annotations

import csv
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from uiux_rule_agent.cli import run
from uiux_rule_agent.config import load_app_config
from uiux_rule_agent.llm_extractor import LLMExtractorError
from uiux_rule_agent.models import RuleRow


class PipelineTest(unittest.TestCase):
    def test_output_directory_can_be_loaded_from_config_and_used(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"

        with tempfile.TemporaryDirectory() as temp_dir:
            configured_output_dir = Path(temp_dir) / "configured-out"
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                f'[input]\nsources = ["{fixture}"]\nmax_pages = 3\n\n'
                f'[output]\ndirectory = "{configured_output_dir}"\n\n'
                '[openai]\napi_key = ""\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "heuristic"\n',
                encoding="utf-8",
            )

            result = run(None, output_dir=None, config_path=str(config_path))

            self.assertEqual(result["output_dir"], str(configured_output_dir))
            self.assertTrue((configured_output_dir / "foundation-rules.csv").exists())
            self.assertTrue((configured_output_dir / "component-rules.csv").exists())
            self.assertTrue((configured_output_dir / "global-layout-rules.csv").exists())

    def test_input_sources_can_be_loaded_from_config(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"

        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "out"
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                f'[input]\nsources = ["{fixture}"]\nmax_pages = 3\n\n'
                '[openai]\napi_key = ""\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "heuristic"\n',
                encoding="utf-8",
            )

            result = run(None, output_dir=str(output_dir), config_path=str(config_path))

            self.assertGreater(result["foundation_rules"], 0)
            self.assertGreater(result["component_rules"], 0)
            self.assertGreater(result["global_rules"], 0)
            self.assertTrue((output_dir / "foundation-rules.csv").exists())

    def test_multiple_remote_sources_can_be_combined_from_config(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "out"
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                '[input]\n'
                'sources = ["https://ant.design/docs/spec/colors-cn", "https://ant.design/docs/spec/font-cn"]\n'
                'max_pages = 2\n\n'
                '[openai]\napi_key = ""\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "heuristic"\n',
                encoding="utf-8",
            )

            result = run(None, output_dir=str(output_dir), config_path=str(config_path))

            self.assertEqual(result["documents"], 2)
            self.assertGreater(result["foundation_rules"], 40)
            self.assertEqual(result["component_rules"], 0)
            self.assertEqual(result["global_rules"], 0)

            with (output_dir / "foundation-rules.csv").open(encoding="utf-8") as handle:
                foundation_rows = list(csv.DictReader(handle))

            self.assertTrue(any(row["subject"] == "品牌主色" for row in foundation_rows))
            self.assertTrue(any(row["subject"] == "主字体字号" for row in foundation_rows))

    def test_cli_input_overrides_configured_input_source(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"

        with tempfile.TemporaryDirectory() as temp_dir:
            output_dir = Path(temp_dir) / "out"
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                '[input]\nsources = ["https://example.com", "https://example.org"]\nmax_pages = 2\n\n'
                '[openai]\napi_key = ""\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "heuristic"\n',
                encoding="utf-8",
            )

            result = run(str(fixture), output_dir=str(output_dir), config_path=str(config_path))

            self.assertGreater(result["foundation_rules"], 0)
            self.assertTrue((output_dir / "foundation-rules.csv").exists())

    def test_remote_and_local_sources_cannot_be_mixed(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                f'[input]\nsources = ["https://example.com", "{fixture}"]\nmax_pages = 2\n\n'
                '[openai]\napi_key = ""\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "heuristic"\n',
                encoding="utf-8",
            )

            with self.assertRaisesRegex(ValueError, "不能混用远程 URL 和本地路径"):
                run(None, output_dir=temp_dir, config_path=str(config_path))

    def test_markdown_pipeline_generates_three_csvs(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"

        with tempfile.TemporaryDirectory() as temp_dir:
            result = run(str(fixture), output_dir=temp_dir, max_pages=1)
            target = Path(temp_dir)

            foundation = target / "foundation-rules.csv"
            component = target / "component-rules.csv"
            global_rules = target / "global-layout-rules.csv"

            self.assertTrue(foundation.exists())
            self.assertTrue(component.exists())
            self.assertTrue(global_rules.exists())
            self.assertGreater(result["foundation_rules"], 0)
            self.assertGreater(result["component_rules"], 0)
            self.assertGreater(result["global_rules"], 0)

            with foundation.open(encoding="utf-8") as handle:
                foundation_rows = list(csv.DictReader(handle))
            with component.open(encoding="utf-8") as handle:
                component_rows = list(csv.DictReader(handle))
            with global_rules.open(encoding="utf-8") as handle:
                global_rows = list(csv.DictReader(handle))

            self.assertTrue(any(row["rule_id"].startswith("FDN-") for row in foundation_rows))
            self.assertTrue(any(row["state"] == "hover" for row in component_rows))
            self.assertTrue(any("If 屏幕宽度 < 600px" in row["condition_if"] for row in global_rows))

    def test_structured_markdown_subdirectories_route_to_matching_csv(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            foundation_dir = root / "foundation-rules"
            component_dir = root / "component-rules"
            global_dir = root / "global-layout-rules"
            foundation_dir.mkdir()
            component_dir.mkdir()
            global_dir.mkdir()

            (foundation_dir / "tokens.md").write_text(
                "# Tokens\n\n- Primary color: #0067D1\n- Card radius: 8px\n",
                encoding="utf-8",
            )
            (component_dir / "button.md").write_text(
                "# Button\n\n```css\n.button { height: 32px; background-color: #0067D1; }\n.button:hover { background-color: #2E86DE; }\n.button[disabled] { opacity: 0.6; }\n```\n",
                encoding="utf-8",
            )
            (global_dir / "layout.md").write_text(
                "# Layout\n\n```css\n@media (max-width: 600px) { .bottom-action-bar { width: 100%; } }\n```\n\n如果 屏幕宽度 < 600px，则 底部操作栏 必须 撑满全屏（100% width），否则 保持桌面端悬浮宽度。\n",
                encoding="utf-8",
            )

            output_dir = root / "out"
            result = run(str(root), output_dir=str(output_dir), max_pages=1)

            self.assertGreater(result["foundation_rules"], 0)
            self.assertGreater(result["component_rules"], 0)
            self.assertGreater(result["global_rules"], 0)

            with (output_dir / "foundation-rules.csv").open(encoding="utf-8") as handle:
                foundation_rows = list(csv.DictReader(handle))
            with (output_dir / "component-rules.csv").open(encoding="utf-8") as handle:
                component_rows = list(csv.DictReader(handle))
            with (output_dir / "global-layout-rules.csv").open(encoding="utf-8") as handle:
                global_rows = list(csv.DictReader(handle))

            self.assertTrue(any(row["subject"] == "Primary color" for row in foundation_rows))
            self.assertFalse(any(row["subject"] == "button" for row in foundation_rows))
            self.assertTrue(any(row["subject"] == "button" and row["state"] == "hover" for row in component_rows))
            self.assertFalse(any(row["prefix"] == "CMP" for row in global_rows))
            self.assertTrue(any("屏幕宽度 < 600px" in row["condition_if"] for row in global_rows))

    def test_official_ant_design_color_spec_uses_builtin_foundation_rules(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run("https://ant.design/docs/spec/colors-cn", output_dir=temp_dir, max_pages=1)
            target = Path(temp_dir)

            self.assertEqual(result["documents"], 1)
            self.assertGreater(result["foundation_rules"], 30)
            self.assertEqual(result["component_rules"], 0)
            self.assertEqual(result["global_rules"], 0)

            with (target / "foundation-rules.csv").open(encoding="utf-8") as handle:
                foundation_rows = list(csv.DictReader(handle))

            self.assertTrue(any(row["subject"] == "品牌主色" and row["default_value"] == "#1677FF" for row in foundation_rows))
            self.assertTrue(any(row["subject"] == "基础色板" and row["property_name"] == "hue-family-count" for row in foundation_rows))

    def test_official_ant_design_font_spec_uses_builtin_foundation_rules(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            result = run("https://ant.design/docs/spec/font-cn/", output_dir=temp_dir, max_pages=1)
            target = Path(temp_dir)

            self.assertEqual(result["documents"], 1)
            self.assertGreaterEqual(result["foundation_rules"], 10)
            self.assertEqual(result["component_rules"], 0)
            self.assertEqual(result["global_rules"], 0)

            with (target / "foundation-rules.csv").open(encoding="utf-8") as handle:
                foundation_rows = list(csv.DictReader(handle))

            self.assertTrue(any(row["subject"] == "主字体字号" and row["default_value"] == "14px" for row in foundation_rows))
            self.assertTrue(any(row["subject"] == "默认字体家族" and "BlinkMacSystemFont" in row["default_value"] for row in foundation_rows))

    def test_llm_extractor_can_be_selected_explicitly(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"
        llm_rows = [
            RuleRow(
                prefix="FDN",
                layer="foundation",
                page_type="foundation",
                subject="LLM 主字号",
                component="",
                state="default",
                property_name="font-size",
                condition_if="If 文本角色 = body",
                then_clause="Then font-size 必须为 14px",
                else_clause="Else 保持默认规则",
                default_value="14px",
                preferred_pattern="使用 LLM 归纳后的 token",
                anti_pattern="不要混用多个正文主字号",
                evidence="mocked llm evidence",
                source_ref=str(fixture),
            )
        ]

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                '[openai]\napi_key = "test-key"\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n[extraction]\nstrategy = "auto"\n',
                encoding="utf-8",
            )

            with patch("uiux_rule_agent.cli.extract_rules_with_llm", return_value=llm_rows):
                result = run(
                    str(fixture),
                    output_dir=temp_dir,
                    max_pages=1,
                    extractor="llm",
                    llm_model="gpt-5.4-mini",
                    config_path=str(config_path),
                )

            self.assertEqual(result["foundation_rules"], 1)
            self.assertEqual(result["component_rules"], 0)
            self.assertEqual(result["global_rules"], 0)

            with (Path(temp_dir) / "foundation-rules.csv").open(encoding="utf-8") as handle:
                foundation_rows = list(csv.DictReader(handle))

            self.assertEqual(foundation_rows[0]["subject"], "LLM 主字号")

    def test_auto_extractor_falls_back_to_heuristic_when_llm_fails(self) -> None:
        fixture = Path(__file__).resolve().parents[1] / "examples" / "sample-guidelines.md"

        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                '[openai]\napi_key = "test-key"\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n[extraction]\nstrategy = "auto"\n',
                encoding="utf-8",
            )

            with patch(
                "uiux_rule_agent.cli.extract_rules_with_llm",
                side_effect=LLMExtractorError("llm unavailable"),
            ):
                result = run(str(fixture), output_dir=temp_dir, max_pages=1, extractor="auto", config_path=str(config_path))
            self.assertGreater(result["foundation_rules"], 0)
            self.assertGreater(result["component_rules"], 0)
            self.assertGreater(result["global_rules"], 0)

    def test_ai_config_file_is_loaded_from_toml(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                '[input]\nsources = ["./docs", "https://example.com/spec"]\nmax_pages = 8\n\n'
                '[output]\ndirectory = "./exports"\n\n'
                '[openai]\napi_key = "demo-key"\nbase_url = "https://example.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "llm"\n',
                encoding="utf-8",
            )

            config = load_app_config(str(config_path))

            self.assertEqual(config.input.sources, ["./docs", "https://example.com/spec"])
            self.assertEqual(config.input.max_pages, 8)
            self.assertEqual(config.output.directory, "./exports")
            self.assertEqual(config.openai.api_key, "demo-key")
            self.assertEqual(config.openai.base_url, "https://example.com/v1")
            self.assertEqual(config.openai.model, "gpt-5.4-mini")
            self.assertEqual(config.extraction.strategy, "llm")

    def test_legacy_single_input_source_is_still_supported(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            config_path = Path(temp_dir) / "ai.toml"
            config_path.write_text(
                '[input]\nsource = "./docs"\nmax_pages = 4\n\n'
                '[openai]\napi_key = ""\nbase_url = "https://api.openai.com/v1"\nmodel = "gpt-5.4-mini"\n\n'
                '[extraction]\nstrategy = "auto"\n',
                encoding="utf-8",
            )

            config = load_app_config(str(config_path))

            self.assertEqual(config.input.sources, ["./docs"])
            self.assertEqual(config.input.max_pages, 4)


if __name__ == "__main__":
    unittest.main()
